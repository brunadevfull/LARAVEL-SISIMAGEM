# SISIMAGEM — Estado atual do projeto (22/set/2026)

Leia este arquivo primeiro. Ele existe porque a quantidade de documentos
gerados ao longo das conversas ficou difícil de acompanhar. Aqui está o que
vale, o que foi descartado, e o que falta.

## Decisão de escopo, resolvida

O projeto é **construir o SISIMAGEM do zero, em Laravel**. Houve um momento
em que se cogitou adotar um produto pronto chamado DPM em vez de construir
— essa ideia foi descartada. Não há mais ambiguidade sobre isso.

## Cronograma real

O cronograma formal (documento em papel, fases JUN26–MAR27) está desatualizado
frente ao ritmo real. Decisão tomada: começar a programar agora (set/2026) e
terminar a programação até nov–dez/2026, o mais rápido possível. O documento
oficial de planejamento ainda precisa ser repactuado com a chefia para
refletir isso — está pendente.

## O que já está pronto (neste pacote)

| Arquivo | O que é |
|---|---|
| `sisimagem-plano-tecnico.md` | **Documento técnico principal.** Stack, modelo de dados completo, regras de conversão, achados de segurança, arquitetura, ordem de construção. Comece por aqui num chat novo. |
| `sisimagem-plano.md` | Divisão de tarefas entre você e os dois militares — o que cada um faz e em que ordem |
| `sisimagem-ddl.sql` | DDL completo das 7 tabelas do banco novo, pronto para rodar num PostgreSQL local de teste |
| `sisimagem-diagrama-er.md` | Diagrama de relacionamentos (Mermaid) do schema acima |
| `sisimagem-fluxos.md` | Fluxogramas do comportamento do sistema (login, busca, inclusão, ETL) |
| `sisimagem-requisitos-fluxos.md` | Roteiro de perguntas para aplicar com o PAPEM-40 — ainda não executado |
| `migrations/` | Migrations do Laravel já escritas, traduzindo o DDL. Por ora só a primeira (extensão de `users`); as demais seguem o mesmo padrão |

## O que foi descartado — não usar

- Um documento de requisitos com termos como "armário", "índice", "OM",
  "reindexação" — era de outro sistema, usado por engano como base. Não tem
  relação com o SISIMAGEM real.
- As planilhas de contagem/consulta já executadas no SQL Developer — os
  resultados delas já estão incorporados no plano técnico; não precisa
  guardar as perguntas em si.
- O roteiro de 9 blocos de extração via Claude Code — já foi executado quase
  por completo; os achados estão consolidados no plano técnico. Só sobrou
  uma pendência dele (ver abaixo).

## Pendências reais

1. **Encoding/charset do legado** — ainda não investigado. Explica por que
   tipos de documento aparecem com acento corrompido (`OF¿CIO`).
2. **Acesso de leitura ao servidor de arquivos** — para confirmar a regra de
   caminho do `RESID` e dimensionar o volume real. Não bloqueia o
   desenvolvimento da aplicação.
3. **Lista canônica de tipos de documento** — depende de entrevista com o
   PAPEM-40 (está no roteiro de requisitos e fluxos).
4. **Decisão disco vs. banco para os arquivos** — depende do número 2.
5. **Repactuação formal do cronograma** com a chefia.

## Achados de segurança do legado (já corrigidos no design do novo)

- SQL Injection confirmado na busca (`DAOTrim.listaDocumento`)
- Path traversal no download de documento (`OperacaoAbrirDocumento`)
- Controle de acesso por perfil é só cosmético — qualquer usuário logado
  pode chamar comandos administrativos direto pela URL
- Senha de reset hardcoded (`"marinha"`) — não reaproveitar
- Perfis reais: ADM, PAPEM40, SASM, e um comportamento padrão residual

## Para abrir um chat novo

Cole o conteúdo de `sisimagem-plano-tecnico.md` (ou peça para eu ler a
memória do projeto, que já foi atualizada com o essencial deste estado) e
diga em que ponto quer continuar — normalmente vai ser "gerar a próxima
migration" ou "seguir com a fatia 1 (login e busca)".
